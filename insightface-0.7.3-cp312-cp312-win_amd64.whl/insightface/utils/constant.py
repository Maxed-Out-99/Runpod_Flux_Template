
DEFAULT_MP_NAME = 'buffalo_l'

